package com.esliceu.PracticaDrawing2SpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaDrawing2SpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticaDrawing2SpringBootApplication.class, args);
	}
}
