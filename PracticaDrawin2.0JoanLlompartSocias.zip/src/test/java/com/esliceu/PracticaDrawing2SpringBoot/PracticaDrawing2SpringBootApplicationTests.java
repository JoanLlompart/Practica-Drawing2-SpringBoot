package com.esliceu.PracticaDrawing2SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaDrawing2SpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
