package com.esliceu.PracticaDrawing2SpringBoot.Exceptions;

public class TakeCanvasException extends RuntimeException{
    public TakeCanvasException(String message) {
        super(message);
    }

}
